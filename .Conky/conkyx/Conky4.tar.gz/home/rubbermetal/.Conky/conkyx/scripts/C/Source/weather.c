#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>

#define METRIC 0

typedef struct {
    char *data;
    size_t size;
} MemoryData;

size_t write_callback(void *ptr, size_t size, size_t nmemb, MemoryData *mem) {
    size_t total_size = size * nmemb;
    mem->data = realloc(mem->data, mem->size + total_size + 1);
    if (mem->data == NULL) {
        printf("Error: Memory allocation failed.\n");
        return 0;
    }

    memcpy(&(mem->data[mem->size]), ptr, total_size);
    mem->size += total_size;
    mem->data[mem->size] = '\0';

    return total_size;
}

void get_weather(const char *location_code) {
    // URL to fetch weather data
    char url[100];
    snprintf(url, sizeof(url), "http://rss.accuweather.com/rss/liveweather_rss.asp?metric=%d&locCode=%s", METRIC, location_code);

    // Make a GET request to the URL
    CURL *curl = curl_easy_init();
    if (curl) {
        MemoryData data;
        data.data = malloc(1);
        data.size = 0;

        curl_easy_setopt(curl, CURLOPT_URL, url);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &data);
        CURLcode res = curl_easy_perform(curl);

        if (res == CURLE_OK) {
            // Look for "<title>Currently: " and extract the weather information after it
            const char *start_tag = "<title>Currently: ";
            char *weather_start = strstr(data.data, start_tag);
            if (weather_start) {
                weather_start += strlen(start_tag);
                char *weather_end = strchr(weather_start, '<');
                if (weather_end) {
                    *weather_end = '\0'; // Null-terminate the weather information
                    printf("%s\n", weather_start);
                } else {
                    printf("Error: Could not find weather data.\n");
                }
            } else {
                printf("Error: Could not find weather data.\n");
            }
        } else {
            printf("Error: Could not fetch weather data.\n");
        }

        // Clean up
        free(data.data);
        curl_easy_cleanup(curl);
    } else {
        printf("Error: Could not initialize curl.\n");
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s location_code\n", argv[0]);
        return 1;
    }

    get_weather(argv[1]);

    return 0;
}
