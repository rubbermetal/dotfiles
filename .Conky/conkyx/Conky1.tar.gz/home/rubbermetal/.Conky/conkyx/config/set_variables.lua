function conky_get_variable(var_name)
    local variables = {
    wireless = "python3 /home/rubbermetal/.Conky/conkyx/scripts/wireless-essid.py"
    }
    return variables[var_name]
end
function conky_get_essid()
    local file = io.popen("python3 /home/rubbermetal/.Conky/conkyx/scripts/wireless-essid.py")
    local output = file:read("*a")
    file:close()
    return output
end